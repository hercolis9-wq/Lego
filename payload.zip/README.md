# LEGO Mosaic (Android, Kotlin + Compose)

App Android que transforma imagens em mosaicos estilo LEGO, com:
- Quantização de cores em CIE Lab (perceptual).
- Dithering Floyd–Steinberg (opcional).
- Paleta padrão e **paleta custom via CSV** (`name,r,g,b`).
- **Placas 1×1, 2×2, 4×4** (agrupamento de studs).
- Exporta PNG (Pictures/LegoMosaic) e CSV (Download) via MediaStore.

## Rodando no Android Studio
1. `File > Open` e selecione a pasta do projeto.
2. Sincronize o Gradle e clique ▶️.
3. API mínima 26.

## Rodando direto no celular (AIDE)
- Copie o projeto para `/sdcard/AIDE/Projects/`, abra com AIDE e clique em **Run**.

## GitHub Actions (CI)
O workflow compila o **APK (debug)** em cada push/PR e publica como **artifact**.

Artifacts: `app-debug.apk` em `app/build/outputs/apk/debug/`.

## Paleta CSV
Formato:
```csv
name,r,g,b
Dark Tan,160,140,104
...
```

## Licença
MIT
