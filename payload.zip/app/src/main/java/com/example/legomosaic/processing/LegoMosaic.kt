
package com.example.legomosaic.processing

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.provider.MediaStore
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.pow

object LegoMosaic {

    data class LegoColor(val name: String, val r: Int, val g: Int, val b: Int, val lab: DoubleArray)

    private val DEFAULT_PALETTE = listOf(
        "White" to intArrayOf(242,243,242),
        "Black" to intArrayOf(27,42,52),
        "Light Bluish Gray" to intArrayOf(163,162,164),
        "Dark Bluish Gray" to intArrayOf(99,95,98),
        "Dark Red" to intArrayOf(123,46,47),
        "Red" to intArrayOf(196,40,28),
        "Dark Green" to intArrayOf(40,127,70),
        "Green" to intArrayOf(75,151,74),
        "Blue" to intArrayOf(13,105,172),
        "Dark Blue" to intArrayOf(0,32,96),
        "Tan" to intArrayOf(215,197,153),
        "Dark Tan" to intArrayOf(160,140,104),
        "Reddish Brown" to intArrayOf(105,64,40),
        "Brown" to intArrayOf(124,92,70),
        "Orange" to intArrayOf(218,133,64),
        "Bright Orange" to intArrayOf(255,140,0),
        "Yellow" to intArrayOf(245,205,47),
        "Bright Light Yellow" to intArrayOf(255,246,123),
        "Dark Orange" to intArrayOf(160,84,45),
        "Sand Green" to intArrayOf(120,144,130),
        "Sand Blue" to intArrayOf(100,120,168),
        "Dark Purple" to intArrayOf(54,34,103),
        "Dark Pink" to intArrayOf(194,122,159),
        "Bright Light Blue" to intArrayOf(180,210,228)
    )

    private fun srgbToLinear(c: Double): Double =
        if (c <= 0.04045) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4)

    private fun rgbToXyz(r: Int, g: Int, b: Int): DoubleArray {
        val R = srgbToLinear(r / 255.0)
        val G = srgbToLinear(g / 255.0)
        val B = srgbToLinear(b / 255.0)
        val x = R*0.4124564 + G*0.3575761 + B*0.1804375
        val y = R*0.2126729 + G*0.7151522 + B*0.0721750
        val z = R*0.0193339 + G*0.1191920 + B*0.9503041
        return doubleArrayOf(x,y,z)
    }

    private fun xyzToLab(xyz: DoubleArray): DoubleArray {
        val Xn = 0.95047; val Yn = 1.0; val Zn = 1.08883
        fun f(t: Double): Double {
            val delta3 = (6.0/29.0).pow(3.0)
            return if (t > delta3) t.pow(1.0/3.0) else (t/(3*(6.0/29.0).pow(2.0)) + 4.0/29.0)
        }
        val x = xyz[0]/Xn; val y = xyz[1]/Yn; val z = xyz[2]/Zn
        val fx = f(x); val fy = f(y); val fz = f(z)
        val L = 116*fy - 16
        val a = 500*(fx - fy)
        val b = 200*(fy - fz)
        return doubleArrayOf(L, a, b)
    }

    private fun rgbToLab(r: Int, g: Int, b: Int): DoubleArray = xyzToLab(rgbToXyz(r,g,b))

    private fun nearestColorLab(lab: DoubleArray, palette: List<LegoColor>): Int {
        var best = 0
        var bestD = Double.POSITIVE_INFINITY
        for (i in palette.indices) {
            val p = palette[i].lab
            val d0 = p[0]-lab[0]; val d1 = p[1]-lab[1]; val d2 = p[2]-lab[2]
            val d = d0*d0 + d1*d1 + d2*d2
            if (d < bestD) { bestD = d; best = i }
        }
        return best
    }

    private fun cropToAspect(bm: Bitmap, targetW: Int, targetH: Int): Bitmap {
        val targetRatio = targetW.toFloat() / targetH.toFloat()
        val inRatio = bm.width.toFloat() / bm.height.toFloat()
        return if (inRatio > targetRatio) {
            val newW = (bm.height * targetRatio).toInt()
            val x = (bm.width - newW)/2
            Bitmap.createBitmap(bm, x, 0, newW, bm.height)
        } else {
            val newH = (bm.width / targetRatio).toInt()
            val y = (bm.height - newH)/2
            Bitmap.createBitmap(bm, 0, y, bm.width, newH)
        }
    }

    private fun loadBitmapFromUri(context: Context, uri: Uri): Bitmap {
        return MediaStore.Images.Media.getBitmap(context.contentResolver, uri)
    }

    private fun loadPaletteCsv(context: Context, uri: Uri?): List<LegoColor> {
        if (uri == null) {
            return DEFAULT_PALETTE.map { (name, rgb) ->
                LegoColor(name, rgb[0], rgb[1], rgb[2], rgbToLab(rgb[0], rgb[1], rgb[2]))
            }
        }
        val list = mutableListOf<LegoColor>()
        context.contentResolver.openInputStream(uri)?.bufferedReader()?.useLines { lines ->
            lines.drop(1).forEach { ln -> // pula o cabeçalho
                val line = ln.trim()
                if (line.isEmpty()) return@forEach
                val parts = line.split(",")
                if (parts.size >= 4) {
                    val name = parts[0]
                    val r = parts[1].toIntOrNull() ?: 0
                    val g = parts[2].toIntOrNull() ?: 0
                    val b = parts[3].toIntOrNull() ?: 0
                    list.add(LegoColor(name, r, g, b, rgbToLab(r, g, b)))
                }
            }
        }
        return if (list.isEmpty()) {
            DEFAULT_PALETTE.map { (name, rgb) ->
                LegoColor(name, rgb[0], rgb[1], rgb[2], rgbToLab(rgb[0], rgb[1], rgb[2]))
            }
        } else list
    }

    fun generate(
        context: Context,
        uri: Uri,
        studsW: Int,
        studsH: Int,
        dither: Boolean,
        drawGrid: Boolean,
        studPx: Int,
        plateSize: Int,
        paletteUri: Uri?
    ): Pair<Bitmap, List<Pair<String,Int>>> {
        val src = loadBitmapFromUri(context, uri)
        val cropped = cropToAspect(src, studsW, studsH)
        val small = Bitmap.createScaledBitmap(cropped, studsW, studsH, true)

        val palette = loadPaletteCsv(context, paletteUri)

        val outW = studsW * studPx
        val outH = studsH * studPx
        val out = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint()
        val grid = Paint().apply {
            style = Paint.Style.STROKE
            color = Color.rgb(40,40,40)
            strokeWidth = 1f
            isAntiAlias = false
        }

        val counts = HashMap<String, Int>()

        if (plateSize <= 1) {
            val L = Array(studsH) { DoubleArray(studsW) }
            val A = Array(studsH) { DoubleArray(studsW) }
            val B = Array(studsH) { DoubleArray(studsW) }
            for (y in 0 until studsH) {
                for (x in 0 until studsW) {
                    val c = small.getPixel(x, y)
                    val lab = rgbToLab(Color.red(c), Color.green(c), Color.blue(c))
                    L[y][x] = lab[0]; A[y][x] = lab[1]; B[y][x] = lab[2]
                }
            }
            for (y in 0 until studsH) {
                for (x in 0 until studsW) {
                    val lab = doubleArrayOf(L[y][x], A[y][x], B[y][x])
                    val idx = nearestColorLab(lab, palette)
                    val q = palette[idx].lab
                    val errL = lab[0] - q[0]
                    val erra = lab[1] - q[1]
                    val errb = lab[2] - q[2]

                    val color = palette[idx]
                    counts[color.name] = (counts[color.name] ?: 0) + 1
                    paint.color = Color.rgb(color.r, color.g, color.b)
                    val left = x * studPx
                    val top = y * studPx
                    val right = left + studPx
                    val bottom = top + studPx
                    canvas.drawRect(left.toFloat(), top.toFloat(), right.toFloat(), bottom.toFloat(), paint)
                    if (drawGrid) canvas.drawRect(left.toFloat(), top.toFloat(), (right-1).toFloat(), (bottom-1).toFloat(), grid)

                    if (dither) {
                        fun add(ix: Int, iy: Int, f: Double) {
                            if (ix !in 0 until studsW || iy !in 0 until studsH) return
                            L[iy][ix] += errL * f
                            A[iy][ix] += erra * f
                            B[iy][ix] += errb * f
                        }
                        add(x+1, y, 7.0/16.0)
                        add(x-1, y+1, 3.0/16.0)
                        add(x, y+1, 5.0/16.0)
                        add(x+1, y+1, 1.0/16.0)
                    }
                }
            }
        } else {
            val block = plateSize
            val blocksX = studsW / block
            val blocksY = studsH / block
            for (by in 0 until blocksY) {
                for (bx in 0 until blocksX) {
                    var sL = 0.0; var sA = 0.0; var sB = 0.0; var n = 0
                    for (yy in 0 until block) {
                        for (xx in 0 until block) {
                            val px = bx*block + xx
                            val py = by*block + yy
                            val c = small.getPixel(px, py)
                            val lab = rgbToLab(Color.red(c), Color.green(c), Color.blue(c))
                            sL += lab[0]; sA += lab[1]; sB += lab[2]; n++
                        }
                    }
                    val avg = doubleArrayOf(sL/n, sA/n, sB/n)
                    val idx = nearestColorLab(avg, palette)
                    val color = palette[idx]
                    counts[color.name] = (counts[color.name] ?: 0) + 1
                    paint.color = Color.rgb(color.r, color.g, color.b)

                    val left = bx * block * studPx
                    val top = by * block * studPx
                    val right = left + block * studPx
                    val bottom = top + block * studPx
                    canvas.drawRect(left.toFloat(), top.toFloat(), right.toFloat(), bottom.toFloat(), paint)
                    if (drawGrid) canvas.drawRect(left.toFloat(), top.toFloat(), (right-1).toFloat(), (bottom-1).toFloat(), grid)
                }
            }
        }

        val sortedCounts = counts.entries.sortedWith(compareByDescending<Map.Entry<String,Int>> { it.value }.thenBy { it.key })
            .map { it.key to it.value }

        return out to sortedCounts
    }

    fun countsToCsv(counts: List<Pair<String,Int>>, plateSize: Int): String {
        val sb = StringBuilder()
        sb.append("color,count,piece\n")
        val piece = if (plateSize <= 1) "1x1" else "${plateSize}x${plateSize}"
        for ((name, qty) in counts) {
            sb.append(name.replace(",", " ")).append(",").append(qty).append(",").append(piece).append("\n")
        }
        return sb.toString()
    }
}
