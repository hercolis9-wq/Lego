
package com.example.legomosaic

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.example.legomosaic.processing.LegoMosaic
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface {
                    AppScreen()
                }
            }
        }
    }
}

@Composable
fun AppScreen() {
    val context = LocalContext.current
    var imageUri by remember { mutableStateOf<Uri?>(null) }
    var studsW by remember { mutableIntStateOf(64) }
    var studsH by remember { mutableIntStateOf(64) }
    var studPx by remember { mutableIntStateOf(20) }
    var dither by remember { mutableStateOf(true) }
    var drawGrid by remember { mutableStateOf(true) }
    var processing by remember { mutableStateOf(false) }
    var mosaic by remember { mutableStateOf<Bitmap?>(null) }
    var counts by remember { mutableStateOf(listOf<Pair<String, Int>>()) }
    var plateSize by remember { mutableIntStateOf(1) }

    // Palette handling
    var paletteUri by remember { mutableStateOf<Uri?>(null) }
    var paletteName by remember { mutableStateOf("Padrão") }

    val pickImage = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
        }
        imageUri = uri
    }

    val pickCsv = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: Exception) {}
            paletteUri = uri
            paletteName = uri.lastPathSegment ?: "Paleta CSV"
        }
    }

    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("🧱 LEGO Mosaic (Android)", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Escolha uma imagem, ajuste os studs e gere o mosaico direto no aparelho.")

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { pickImage.launch(arrayOf("image/*")) }) {
                Text("Selecionar imagem")
            }
            Button(onClick = { pickCsv.launch(arrayOf("text/*", "application/*")) }) {
                Text("Paleta CSV")
            }
            if (mosaic != null) {
                Button(onClick = {
                    val name = timeStamp("yyyyMMdd_HHmmss")
                    saveBitmapToPictures(context, mosaic!!, "Mosaic_${name}.png")
                    val csv = LegoMosaic.countsToCsv(counts, plateSize)
                    saveTextToDownloads(context, csv, "Counts_${name}.csv")
                }) {
                    Text("Salvar PNG + CSV")
                }
            }
        }

        Text("Paleta atual: " + paletteName)

        if (imageUri == null) {
            Text("Nenhuma imagem selecionada.")
        } else {
            AsyncImage(model = imageUri, contentDescription = "Original", modifier = Modifier.height(200.dp).fillMaxWidth())
        }

        // Controls
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Largura (studs): " + studsW)
            Slider(value = studsW.toFloat(), onValueChange = { studsW = it.toInt().coerceIn(16, 256) }, valueRange = 16f..256f)
            Text("Altura (studs): " + studsH)
            Slider(value = studsH.toFloat(), onValueChange = { studsH = it.toInt().coerceIn(16, 256) }, valueRange = 16f..256f)
            Text("Tamanho visual do stud (preview): " + studPx + " px")
            Slider(value = studPx.toFloat(), onValueChange = { studPx = it.toInt().coerceIn(8, 40) }, valueRange = 8f..40f)

            Text("Tamanho de placa: " + plateSize + "×" + plateSize)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(1,2,4).forEach { sz ->
                    FilterChip(selected = plateSize == sz, onClick = { plateSize = sz }, label = { Text(sz.toString() + "×" + sz.toString()) })
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = dither, onCheckedChange = { dither = it })
                Text("Dithering (Floyd–Steinberg, Lab)")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = drawGrid, onCheckedChange = { drawGrid = it })
                Text("Desenhar grade")
            }
            Button(
                enabled = imageUri != null && !processing,
                onClick = {
                    processing = true
                    scope.launch(Dispatchers.Default) {
                        val (bmp, cnt) = LegoMosaic.generate(
                            context = context,
                            uri = imageUri!!,
                            studsW = studsW,
                            studsH = studsH,
                            dither = dither,
                            drawGrid = drawGrid,
                            studPx = studPx,
                            plateSize = plateSize,
                            paletteUri = paletteUri
                        )
                        mosaic = bmp
                        counts = cnt
                        processing = false
                    }
                }
            ) {
                Text(if (processing) "Processando..." else "Gerar mosaico")
            }
        }

        mosaic?.let { m ->
            Text("Mosaico (preview)", fontWeight = FontWeight.Bold)
            Image(bitmap = m.asImageBitmap(), contentDescription = "Mosaic", modifier = Modifier.fillMaxWidth())
            Text("Contagem de peças (top 10):")
            counts.take(10).forEach { (name, qty) ->
                Text("• " + name + ": " + qty)
            }
        }
    }
}

fun timeStamp(fmt: String): String = SimpleDateFormat(fmt, Locale.getDefault()).format(Date())

fun saveBitmapToPictures(context: android.content.Context, bitmap: Bitmap, fileName: String): Uri? {
    val resolver = context.contentResolver
    val contentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
        put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/LegoMosaic")
        }
    }
    val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues) ?: return null
    resolver.openOutputStream(uri)?.use { out ->
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
    }
    return uri
}

fun saveTextToDownloads(context: android.content.Context, text: String, fileName: String): Uri? {
    val resolver = context.contentResolver
    val contentValues = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
        put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            put(MediaStore.Downloads.RELATIVE_PATH, "Download")
        }
    }
    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues) ?: return null
    resolver.openOutputStream(uri)?.use { out: OutputStream ->
        out.write(text.toByteArray())
        out.flush()
    }
    return uri
}
